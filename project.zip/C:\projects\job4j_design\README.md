# Junior level

- *2.1. Data structures and algorithms*

- *2.2. Input/Output*

- *2.3. SQL, JDBC*

- *2.4. Garbage Collection*

- *2.5. Clean architecture*

- *2.6. Algorithms in the interview*
